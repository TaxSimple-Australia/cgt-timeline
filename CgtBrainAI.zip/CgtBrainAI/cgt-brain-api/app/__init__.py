"""CGT Brain API - Australian Capital Gains Tax Calculator."""

__version__ = "1.0.0"
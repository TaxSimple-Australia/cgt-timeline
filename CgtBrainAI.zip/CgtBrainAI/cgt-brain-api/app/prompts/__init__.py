"""Prompt templates for CGT Brain API."""

from .system_prompt import SYSTEM_PROMPT

__all__ = ["SYSTEM_PROMPT"]

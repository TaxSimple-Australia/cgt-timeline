"""CGT Brain API routers package."""

from .portfolio import router as portfolio_router

__all__ = ["portfolio_router"]

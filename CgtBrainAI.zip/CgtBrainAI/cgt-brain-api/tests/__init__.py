"""Tests for CGT Brain API."""
